let textBody;

let key = 'asKhJsaD12ASghI';

function getText(){
    textBody = document.getElementById("myText").value;
}

function encrypt(){
    getText();

    var encrypted = CryptoJS.AES.encrypt(textBody, key);
    document.getElementById("myText").value = encrypted;

    var copyText = document.getElementById("myText");

    /* COPY TEXT */
    copyText.select();
    copyText.setSelectionRange(0, 99999);
    document.execCommand("copy");
    copyText.setSelectionRange(0, 0);

    var decrypted = CryptoJS.AES.decrypt(encrypted, key);
    let result = decrypted.toString(CryptoJS.enc.Utf8);

    copyText.value = result;

    M.toast({html: 'Encryted Text copied to clipboard'}).displayLength(5).inDuration(300).outDuration(300);
}

function decrypt(){
    getText();
    let result;

    var decrypted = CryptoJS.AES.decrypt(textBody, key);
    result = decrypted.toString(CryptoJS.enc.Utf8);

    document.getElementById('decryption-output').textContent = result;
}

function cursify(){
    getText();

    document.getElementById("myText").value = '';

    let text = textBody;

    text.split('').map(char => {
        if     (char == "I" || char == "i") char = '1';
        else if(char == "Z" || char == "z") char = '2';
        else if(char == "E" || char == "e") char = '3';
        else if(char == "A" || char == "a") char = '4';
        else if(char == "S" || char == "s") char = '5';
        else if(char == "G" || char == "g") char = '6';
        else if(char == "T" || char == "t") char = '7';
        else if(char == "B" || char == "b") char = '8';
        else if(char == "O" || char == "o") char = '0';

        document.getElementById("myText").value += char.toString();
    });

    var copyText = document.getElementById("myText");

    /* COPY TEXT */
    copyText.select();
    copyText.setSelectionRange(0, 99999);
    document.execCommand("copy");
    copyText.setSelectionRange(0, 0);

    copyText.value = textBody;

    M.toast({html: 'Cursed Text copied to clipboard'}).displayLength(5).inDuration(300).outDuration(300);
}